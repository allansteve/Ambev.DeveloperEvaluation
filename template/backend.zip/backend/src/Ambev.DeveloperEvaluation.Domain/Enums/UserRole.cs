namespace Ambev.DeveloperEvaluation.Domain.Enums;

public enum UserRole
{
    None = 0,
    Customer,    
    Manager,
    Admin,
}